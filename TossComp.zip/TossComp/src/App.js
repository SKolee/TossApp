import './App.css';
import Coin from './Components/Coin';
import Button from './Components/Button'
import { useState } from 'react';
import Result from './Components/Result';


function App() {
  const[coin,setCoin]=useState()
  
  const coinFlip=()=>{
    let random=Math.floor(Math.random() * 2) + 1
    setCoin(random)
    console.log(coin)
  }

  
  return (
    
      <div className="App">
        
        <Coin coinVal={coin}/>
        <br/>
        <Button buttonFunction={coinFlip}/>
        
        <Result coinVal={coin} /> 

      </div>
   

  );//Resuable Component
}

export default App;

