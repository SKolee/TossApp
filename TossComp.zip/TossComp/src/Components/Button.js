import './Button.css'
import './Coin.css'
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>

export default function Coin({buttonFunction}){
    return(
        <div className='button-op'>
        <input id='flip' type='button' onClick={buttonFunction} value={'Flip'}/>
        <input id='flip' type='button' onClick={()=>window.location.reload(false)} value='Reset'/>
        </div>
    )
}
// window.location.reload(false)