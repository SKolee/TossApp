import './Button.css'
export default function Result({ coinVal }) {
    let message = ''
    if (coinVal === 1) {
        message = `It's Heads`
    }
    else if (coinVal === 2) {
        message = `It's Tails`
    }

    else if (!coinVal) {
        message = `Flip the Coin`
    }
    return (
        <div className='result-div'>
            <h2>{message}</h2>
        </div>
    )
}