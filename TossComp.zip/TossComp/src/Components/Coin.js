import './Coin.css'
export default function Coin({coinVal}){
    let imagePath=''
    
    if(!coinVal ){
        imagePath='hello.jpg'
    }
    else{
        imagePath=`${coinVal}.jpg`
    }
    return(
        <>
        <div className='coin-img'><img id="img" style={{ width:'270px', height:'270px' }} src={imagePath} alt='coin'/></div>
        </>
    )

    
}